import * as fn from "./fn"

export default function () {
  return { fn }
}
